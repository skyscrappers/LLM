import os
import json
from groq import Groq
from fastapi import FastAPI
from pydantic import BaseModel
import read_emails
import general_chat
import visual_question_answering
import send_mail
import time , internet_search

os.environ["GROQ_API_KEY"] = "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"
client = Groq(api_key=os.getenv('GROQ_API_KEY'))

MODEL = "llama-3.1-8b-instant"
MAX_RETRIES = 15
RETRY_DELAY = 0

app = FastAPI()

class ChatRequest(BaseModel):
    user_prompt: str

def attempt_run_conversation(user_prompt, retries=0):
    messages = [
        {
            "role": "system",
            "content": "You are a function-calling LLM that chooses appropriate tools based on the user's request."
        },
        {
            "role": "user",
            "content": user_prompt,
        }
    ]
    
    tools = [
        {
            "type": "function",
            "function": {
                "name": "read_emails",
                "description": "Read the user's emails",
            }
        },
        {
            "type": "function",
            "function": {
                "name": "general_chat",
                "description": "Respond to general user queries",
            }
        },
        {
            "type": "function",
            "function": {
                "name": "visual_question_answering",
                "description": "Answer questions related to an image input",
            }
        },
        {
            "type": "function",
            "function": {
                "name": "send_email",
                "description": "Send an email to some email ID",
            }
        },
        {
            "type": "function",
            "function": {
                "name": "internet_search",
                "description": "Search some information from the internet",
            }
        }
    ]
    
    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=messages,
            tools=tools,
            tool_choice="auto",
            max_tokens=4096
        )
        
        response_message = response.choices[0].message
        
        if hasattr(response_message, 'tool_calls') and response_message.tool_calls:
            tool_calls = response_message.tool_calls
            for tool_call in tool_calls:
                tool_name = tool_call.function.name
                if tool_name == "read_emails":
                    return read_emails.read_emails()
                elif tool_name == "general_chat":
                    return general_chat.general_chat(user_prompt)
                elif tool_name == "visual_question_answering":
                    return visual_question_answering.visual_question_answering("dummy_image_data")
                elif tool_name == "send_email":
                    return send_mail.send_mail(user_prompt)
                elif tool_name == "internet_search":
                    return internet_search.internet_search(user_prompt)
        else:
            raise ValueError("No tools called.")

    except (ValueError, Exception) as e:
        print(f"Error: {e}, retrying in {RETRY_DELAY} seconds...")
        if retries < MAX_RETRIES:
            time.sleep(RETRY_DELAY)
            return attempt_run_conversation(user_prompt, retries + 1)
        else:
            raise e

@app.post("/run_conversation")
def run_conversation(request: ChatRequest):
    user_prompt = request.user_prompt
    try:
        result = attempt_run_conversation(user_prompt)
        return result
    except Exception as e:
        return {"error": str(e)}
