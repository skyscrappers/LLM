import requests
import os
from groq import Groq

serpapi_api_key = '7b4b019693fea4c89cfcf348c7c9a3f8552468b40d3c87718e21ece986638f5a'

def internet_search(query):
    url = "https://serpapi.com/search.json"
    params = {
        "engine": "google",
        "q": query,
        "api_key": serpapi_api_key,
        "hl": "en",
        "gl": "in",
    }
    response = requests.get(url, params=params)
    
    if response.status_code == 200:
        results = response.json()
        if 'answer_box' in results:
            if 'snippet' in results['answer_box']:
                return results['answer_box']['snippet']
            if 'answer' in results['answer_box']:
                return results['answer_box']['answer']
        if 'organic_results' in results and 'snippet' in results['organic_results'][0]:
            return results['organic_results'][0]['snippet']
    return "Search failed"

def llama_answer_from_search(search_text):
    os.environ["GROQ_API_KEY"] = "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"
    client = Groq(api_key=os.getenv('GROQ_API_KEY'))
    MODEL = "llama-3.1-8b-instant"
    
    messages = [
        {
            "role": "system",
            "content": "Use the following information to answer the user's query based on relevant information."
        },
        {
            "role": "user",
            "content": search_text,
        }
    ]
    response = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        tool_choice="auto",
        max_tokens=8000
    )

    return response.choices[0].message.content

def internet_search_and_llama_response(query):
    search_info = internet_search(query)
    
    if search_info == "Search failed":
        return search_info
    final_answer = llama_answer_from_search(search_info)
    
    return final_answer
