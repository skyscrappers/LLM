def general_chat(user_prompt):
    return {"message": f"Tool: General chat response for: '{user_prompt}'"}
